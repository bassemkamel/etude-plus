import i18n from "i18next";
import { initReactI18next } from "react-i18next";
import fr from "./locales/fr.json";
import en from "./locales/en.json";
import ar from "./locales/ar.json";

const saved = localStorage.getItem("lang") ?? "fr";

i18n.use(initReactI18next).init({
  resources: {
    fr: { translation: fr },
    en: { translation: en },
    ar: { translation: ar },
  },
  lng: saved,
  fallbackLng: "fr",
  interpolation: { escapeValue: false },
});

// Apply RTL direction on language change
function applyDir(lang: string) {
  document.documentElement.dir = lang === "ar" ? "rtl" : "ltr";
  document.documentElement.lang = lang;
}

applyDir(saved);
i18n.on("languageChanged", (lang) => {
  localStorage.setItem("lang", lang);
  applyDir(lang);
});

export default i18n;
